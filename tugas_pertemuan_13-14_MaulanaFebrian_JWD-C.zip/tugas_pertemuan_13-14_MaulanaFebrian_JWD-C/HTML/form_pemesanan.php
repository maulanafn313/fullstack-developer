<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../bootstrap_extract/css/bootstrap.min.css">
    <link rel="stylesheet" href="../CSS/form_pemesanan.css">
</head>
<body>
<nav class="navbar navbar-expand-lg " style="background-color: #996515;">
        <div class="container-fluid">
                <img src="../image/wonderful.jpg" alt="Logo" width="200" height="100" class="d-inline-block align-text-center rounded">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
                <a class="nav-link text-white" href="wisata.php">Beranda</a>
                <a class="nav-link text-white" href="#">Tempat Wisata</a>
                <a class="nav-link text-white" href="#">Harga Wisata</a>
                <a class="nav-link text-white" href="#">Sewa Tempat</a>
                <a class="nav-link text-white" href="daftar_pesanan.php">Modifikasi Pesanan</a>
            </div>
            </div>
        </div>
</nav>
    
    <div class="konten_pemesanan  p-3" style="background-color: #50C878;">
        <h1 class="text-center">Form Pemesanan</h1>
        <form action="insert_pesanan.php" method="post">
            <div class="mb-3">
                <label for="nama_pemesan" class="form-label">Nama Pemesan:</label>
                <input type="text" class="form-control" aria-describedby="name" name="nama_pemesan">
            </div>

            <div class="mb-3">
                <label for="nomor_hp" class="form-label">Nomor Handphone:</label>
                <input type="text" inputmode="numeric" class="form-control" aria-describedby="nomor_hp" name="nomor_hp">
            </div>

            <div class="mb-3">
                <label for="tanggal_pesan" class="form-label">Tanggal Pemesanan:</label>
                <input type="date" class="form-control" aria-describedby="tanggal_pesan" name="tanggal_pesan">
            </div>

            <div class="mb-3">
                <label for="waktu_perjalanan" class="form-label">Waktu Pelaksanaan Perjalanan:</label>
                <input type="text" inputmode="numeric" class="form-control" aria-describedby="waktu_perjalanan" name="waktu_perjalanan">
            </div>

            <div class="mb-3">
                <label class="mb-3">Pelayanan Paket Perjalanan:</label>
                <br>
                <label>Penginapan (Rp.1.000.000)</label>
                <input class="ms-3 mb-3" type="checkbox" name="penginapan" value="1000000">
                <br>
                <label>Transportasi(Rp.1.200.000)</label>
                <input class="ms-3 mb-3" type="checkbox" name="transportasi" value="1200000">
                <br>
                <label>Servis/makan (Rp.500.000)</label>
                <input class="ms-3 mb-3" type="checkbox" name="servis_makan" value="500000">
            </div>

            <div class="mb-3">
                <label for="jumlah_peserta" class="form-label">Jumlah Peserta:</label>
                <input type="text" inputmode="numeric" class="form-control" aria-describedby="jumlah_peserta" name="jumlah_peserta">
            </div>

            <div class="mb-3">
                <label for="harga_paket" class="form-label">Harga Paket Perjalanan:</label>
                <input type="text" inputmode="numeric" class="form-control" aria-describedby="harga_paket" name="harga_paket" id="harga_paket" readonly>
            </div>

            <div class="mb-3">
                <label for="jumlah_tagihan" class="form-label">Jumlah Tagihan:</label>
                <input type="text" inputmode="numeric" class="form-control" aria-describedby="jumlah_tagihan" name="jumlah_tagihan" id="jumlah_tagihan" readonly>
            </div>

            <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
            <button type="button" name="Hitung" class="btn btn-primary" onclick="hitungTagihan()">Hitung</button>
            <button type="reset" name="reset" class="btn btn-danger">Reset</button>
        </form>

        <script>
        function hitungTagihan() {
            // Harga layanan
            let totalLayanan = 0;
            if (document.querySelector('input[name="penginapan"]').checked) {
                totalLayanan += parseInt(document.querySelector('input[name="penginapan"]').value);
            }
            if (document.querySelector('input[name="transportasi"]').checked) {
                totalLayanan += parseInt(document.querySelector('input[name="transportasi"]').value);
            }
            if (document.querySelector('input[name="servis_makan"]').checked) {
                totalLayanan += parseInt(document.querySelector('input[name="servis_makan"]').value);
            }

            // Mengisi input harga paket
            document.getElementById('harga_paket').value = totalLayanan;

            // Menghitung jumlah tagihan
            let jumlahPeserta = parseInt(document.querySelector('input[name="jumlah_peserta"]').value);
            let waktuPerjalanan = parseInt(document.querySelector('input[name="waktu_perjalanan"]').value);
            let jumlahTagihan = jumlahPeserta * waktuPerjalanan * totalLayanan;

            // Mengisi input jumlah tagihan
            document.getElementById('jumlah_tagihan').value = jumlahTagihan;
        }
        </script>
    </div>
    <script src="../bootstrap_extract/js/bootstrap.min.js"></script>
</body>
</html>






