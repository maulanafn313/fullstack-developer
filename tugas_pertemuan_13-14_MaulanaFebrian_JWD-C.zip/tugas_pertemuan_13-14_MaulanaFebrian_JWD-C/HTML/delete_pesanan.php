<?php
include('connection.php');
$id_pemesan =$_GET['id_pemesan'];

try {
    mysqli_query($connection, "DELETE from daftar_pemesanan WHERE id_pemesan = $id_pemesan");
    header("location:daftar_pesanan.php?=delete_success");
} catch (Exception $e) {
    echo "gagal menghapus". $e -> getMessage();
}
?>