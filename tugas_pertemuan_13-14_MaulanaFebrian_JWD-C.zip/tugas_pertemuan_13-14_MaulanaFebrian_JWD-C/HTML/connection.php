<?php
try {
    $connection = mysqli_connect("localhost", "root", "", "db_wisata");
} catch (Exception $e) {
    echo "failed ". $e->getMessage();
}
?>