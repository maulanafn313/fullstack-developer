<?php
include('connection.php');

    $nama_pemesan = $_POST['nama_pemesan'];
    $nomor_hp = $_POST['nomor_hp'];
    $tanggal_pemesanan = $_POST['tanggal_pesan'];
    $waktu_perjalanan = $_POST['waktu_perjalanan'];
    $penginapan = $_POST['penginapan'];
    $transportasi = $_POST['transportasi'];
    $servis_makan = $_POST['servis_makan'];
    $jumlah_peserta = $_POST['jumlah_peserta'];
    $harga_paket = $_POST['harga_paket'];
    $jumlah_tagihan = $_POST['jumlah_tagihan'];


try {
    mysqli_query($connection, "INSERT INTO daftar_pemesanan (id_pemesan,nama_pemesan,nomor_hp,tanggal_pesan,waktu_perjalanan,penginapan,transportasi,servis_makan,jumlah_peserta,harga_paket,jumlah_tagihan) VALUES ('$id_pemesan','$nama_pemesan','$nomor_hp','$tanggal_pemesanan','$waktu_perjalanan','$penginapan','$transportasi','$servis_makan','$jumlah_peserta','$harga_paket','$jumlah_tagihan')");
    header("location: daftar_pesanan.php?=success");
}
catch (Exception $e) {
    echo $e->getMessage();
}
?>