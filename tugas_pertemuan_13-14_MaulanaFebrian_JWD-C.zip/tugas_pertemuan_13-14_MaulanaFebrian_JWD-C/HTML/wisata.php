<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wisata Pangalengan</title>
    <link rel="stylesheet" href="../bootstrap_extract/css/bootstrap.min.css">
    <link rel="stylesheet" href="../CSS/wisata.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg " style="background-color: #996515;">
        <div class="container-fluid">
                <img src="../image/wonderful.jpg" alt="Logo" width="200" height="100" class="d-inline-block align-text-center rounded">
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
              <a class="nav-link text-white" href="#">Beranda</a>
              <a class="nav-link text-white" href="#">Tempat Wisata</a>
              <a class="nav-link text-white" href="#">Harga Wisata</a>
              <a class="nav-link text-white" href="form_pemesanan.php">Sewa Tempat</a>
              <a class="nav-link text-white" href="#">Galeri</a>
            </div>
          </div>
        </div>
      </nav>

        <div class="container-fluid" style="background-color: #50C878;">        
            <div class="col-md-12">
                <div class="img-wisata p-4">
                    <h2 class="text-center text-white display-3">Wisata Pangalengan</h2>
                    <div class="content-image-works d-flex justify-content-center text-center">
                        <div class="column">
                            <div class="situ">
                                <img src="../image/WayangWindu.jpg" class="img-fluid rounded" width="350" >
                                <h4 class="text-white">Wayang Windu</h4>
                            </div>
    
                            <div class="hutan">
                                <img src="../image/RaftingCileunca.jpg" class="img-fluid rounded" width="350" >
                                <h4 class="text-white">Rafting Cileunca</h4>
                            </div>
    
                            <div class="rafting">
                                <img src="../image/hutanPinusrahong.jpg" class="img-fluid rounded" width="350" >
                                <h4 class="text-white">Hutan Pinus Rahong</h4>
                            </div>

                            <div class="wayang">
                                <img src="../image/situCileunca.jpg" class="img-fluid rounded" width="350" >
                                <h4 class="text-white">Situ Cileunca</h4>
                            </div>

                            <div class="pineus">
                                <img src="../image/pineusTilu.jpg" class="img-fluid rounded" width="350" >
                                <h4 class="text-white">Pineus Tilu</h4>
                            </div>
                        </div>                       
                    </div>
                </div>
            </div>
        </div>

        <div class="container-fluid" style="background-color: #F4F6F7;">
            <div class="berita row text-center d-flex justify-content-center">
                <h1>Informasi Wisata</h1>
                <div class="kemah col-md-6 col-sm-12 my-3 border rounded bg-body-tertiary">
                    <img src="../image/kemah.jpg" width="400" class="img-fluid">
                    <p class="lead mt-3">Diskon 25% camping akhir tahun situ Cileunca, mulai dari 21-30 Desember 2023</p>
                    <a class="btn btn-outline-info" href="form_pemesanan.php" role="button">Pesan Sekarang</a>
                </div>

                <div class="rafting col-md-6 col-sm-12 my-3 border rounded bg-body-tertiary">
                    <img src="../image/diskonrafting.jpg" width="400" class="img-fluid">
                    <p class="lead mt-3">Nikmati serunya arum jeram di Rafting Cileunca, dapatkan diskon 10% disetiap weekend, ayo cobain!</p>
                    <button class="btn btn-outline-info" href="#" role="button">Pesan Sekarang</button>
                </div>

                <div class="hutanPinus col-md-6 col-sm-12 my-3 border rounded bg-body-tertiary">
                    <img src="../image/Hutan-Pinus-Rahong-Pangalengan.jpg"  width="400" class="img-fluid">
                    <p class="lead mt-3">Rasakan sunyinya berkemah di hutan Pinus Rahong, ada paket keluarga berkemah Rp.400.000. Segera ajak keluarga kalian!</p>
                    <button class="btn btn-outline-info" href="#" role="button">Pesan Sekarang</button>
                </div>

                <div class="wayangWindu col-md-6 col-sm-12 my-3 border rounded bg-body-tertiary">
                    <img src="../image/wisata_wayang_windu_panenjoan_di_pangalengan.jpg"  width="540" class="img-fluid">
                    <p class="lead mt-3">Nikmati sensasi alam dari wayang windu, diskon 20% di hari Minggu, 24 November 2023. Ayo ajak teman-teman kalian!</p>
                    <button class="btn btn-outline-info" href="#" role="button">Pesan Sekarang</button>
                </div>
            </div>
        </div>

        <div class="container-fluid text-center" style="background-color: #50C878;" >
            <h2 class="display-4 text-white mb-4">Objek Wisata</h2>
                <div class="ratio ratio-16x9 mx-auto" style="width: 50%;">
                    <iframe src="https://www.youtube.com/embed/PhBFDDl6LVM?si=CLhp1-GauXXtbOIg" class="pb-2" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
                </div>
        </div>

        <footer class="container-fluid text-center" style="background-color: #996515;">
            <h2 class="text-white p-3">Wisata Pangalengan 2024</h2>
            <div class="column mt-2 d-flex justify-content-center">
                <a href="#" class="twitter mx-2">
                    <img src="../image/twitter.png" width="30">
                </a>

                <a href="#" class="facebook mx-2">
                    <img src="../image/facebook.png" width="30">
                </a>

                <a href="#" class="youtube mx-2">
                    <img src="../image/youtube.png" width="30">
                </a>
            </div>
        </footer>
    <script src="../bootstrap_extract/js/bootstrap.min.js"></script>
</body>
</html> 