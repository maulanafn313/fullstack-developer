<?php
include('connection.php');
$query = mysqli_query($connection, "SELECT * FROM daftar_pemesanan");
$result = mysqli_fetch_all($query, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Daftar Pesanan</title>
        <link rel="stylesheet" href="../bootstrap_extract/css/bootstrap.min.css">
        <link rel="stylesheet" href="../CSS/form_pemesanan.css">
    </head>
    <body>
        <nav class="navbar navbar-expand-lg " style="background-color: #996515;">
            <div class="container-fluid">
                    <img src="../image/wonderful.jpg" alt="Logo" width="200" height="100" class="d-inline-block align-text-center rounded">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                    <a class="nav-link text-white" href="wisata.php">Beranda</a>
                    <a class="nav-link text-white" href="#">Tempat Wisata</a>
                    <a class="nav-link text-white" href="#">Harga Wisata</a>
                    <a class="nav-link text-white" href="form_pemesanan.php">Sewa Tempat</a>
                    <a class="nav-link text-white" href="#">Modifikasi Pesanan</a>
                    </div>
                </div>
            </div>
        </nav>

        <div class="table-responsive">
            <table class="table table-hover table-bordered">
                <thead>
                    <tr>
                    <th>Id Pesanan</th>
                    <th>Nama Pesanan</th>
                    <th>Nomor Handphone</th>
                    <th>Tanggal Pemesanan</th>
                    <th>Waktu Perjalanan</th>
                    <th>Penginapan</th>
                    <th>Transportasi</th>
                    <th>Servis/makan</th>
                    <th>Jumlah Peserta</th>
                    <th>Harga Paket</th>
                    <th>Jumlah Tagihan</th>
                    <th>Aksi</th>
                    </tr>
                </thead>
            
                <?php foreach($result as $row) : ?>
                    <tbody>
                        <tr>
                            <td><?= $row["id_pemesan"]; ?></td>
                            <td><?= $row["nama_pemesan"]; ?></td>
                            <td><?= $row["nomor_hp"]; ?></td>
                            <td><?= date("d-m-Y", strtotime($row["tanggal_pesan"])); ?></td>
                            <td><?= $row["waktu_perjalanan"]." hari"; ?></td>
                            <td><?= "Rp " . number_format($row["penginapan"], 0, ',', '.'); ?></td>
                            <td><?= "Rp " . number_format($row["transportasi"], 0, ',', '.'); ?></td>
                            <td><?= "Rp " . number_format($row["servis_makan"], 0, ',', '.'); ?></td>
                            <td><?= $row["jumlah_peserta"]. " Orang"; ?></td>
                            <td><?= "Rp " . number_format($row["harga_paket"], 0, ',', '.'); ?></td>
                            <td><?= "Rp " . number_format($row["jumlah_tagihan"], 0, ',', '.'); ?></td>
                            <td >
                                <a href="edit_pesanan.php?id_pemesan=<?= $row["id_pemesan"]; ?>" class="btn btn-primary mb-2">Edit</a>
                                <a href="delete_pesanan.php?id_pemesan=<?= $row["id_pemesan"]; ?>" class="btn btn-danger" onclick="confirmDelete(<?= $row["id_pemesan"]; ?>)">Delete</a>   
                            </td>
                        </tr>
                    </tbody>
                <?php endforeach; ?>
            </table>
        </div>
        <script>
            function confirmDelete(id_pemesan) {
                var answer = confirm("Apakah anda yakin ingin menghapus data pesanan dengan id " + id_pemesan + "?");

                if (answer) {
                    window.location.href = "delete_pesanan.php?id_pemesan=" + id_pemesan;
                } else {
                    return false;
                }
            }
        </script>
    </body>
</html>

        
