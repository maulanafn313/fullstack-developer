Dokumentasi dari website beasiswa ini terdiri dari 5 file:
1. Halaman_utama.php adalah bagian utama dari tampilan website beasiswa kampusku aja. Halaman ini ada menu Home, Daftar Beasiswa, Hasil Pendaftaran Beasiswa
2. Koneksi_database.php adalah file yang berisi kode untuk menghubungkan ke database phpmyadmin
3. daftar_beasiswa.php adalah file yang berisi form untuk mengisi data pendaftar beasiswa yang kemudian datanya akan diproses di proses_pendaftaran_beasiswa.php, lalu hasilnya akan ditampilkan di halaman hasil_pendaftaran_beasiswa.php.
4. proses_pendaftaran_beasiswa.php adalah file yang berisi kode untuk mengeksekusi hasil inputan pengguna dari halaman daftar_beasiswa.php yang kemudian hasilnya akan dikirimkan ke hasil_pendaftaran_beasiswa.php.
5.hasil_pendaftaran_beasiswa.php adalah file yang berisi kode untuk menerima hasil inputan pendaftaran dari pengguna yang diproses dari file daftar_beasiswa.php dan proses_pendaftaran_beasiswa.php.