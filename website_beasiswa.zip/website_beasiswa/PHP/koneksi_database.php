<?php
try{
    $connection = mysqli_connect("localhost", "root", "", "daftar_beasiswa");
}
catch (Exception $e){
    echo "failed ". $e->getMessage();
}

function insert_data($connection){
    if (isset($_POST['daftar'])) {
        $nama = mysqli_real_escape_string($connection, $_POST['nama']);
        $email = mysqli_real_escape_string($connection, $_POST['email']);
        $nomor_hp = mysqli_real_escape_string($connection, $_POST['nomor_hp']);
        $semester = mysqli_real_escape_string($connection, $_POST['semester']);
        $ipk = mysqli_real_escape_string($connection, $_POST['ipk']);
        $pilihan_beasiswa = mysqli_real_escape_string($connection, $_POST['pilihan_beasiswa']);
        $status = mysqli_real_escape_string($connection, $_POST['status']);

        // Upload berkas
        if($_FILES['berkas']['error'] === 4) {
            "<script>alert('File tidak boleh kosong!')</script>";
        }
        else{
            $fileName = $_FILES['berkas']['name'];
            $fileSize = $_FILES['berkas']['size'];
            $tmpName = $_FILES['berkas']['tmp_name'];

            // var_dump($fileName, $fileSize, $tmpName); die;
            $validFileextension = ['pdf'];
            $fileExtension = explode('.', $fileName);
            $fileExtension = strtolower(end($fileExtension));
            if(in_array($fileExtension, $validFileextension)) {
                echo "
                <script>
                    alert('File yang diupload harus berformat PDF!');
                </script>
                ";
            }

            else if($fileSize > 1000000) {
                echo "
                <script>
                    alert('File yang diupload terlalu besar!');
                </script>
                ";
            }

            $newFileName = uniqid();
            $newFileName .= '.' . $fileExtension;
            // var_dump($newFileName); die();
            $directoryFile = __DIR__ . '/../berkas/' . $newFileName;
            // var_dump($directoryFile); die();
            move_uploaded_file($tmpName, $directoryFile);
            $berkas = $newFileName;
            
        }


        // Simpan data ke database
        $query = "INSERT INTO data_pendaftar (nama, email, nomor_hp, semester, ipk, pilihan_beasiswa, berkas, status) VALUES ('$nama', '$email', '$nomor_hp', '$semester', '$ipk', '$pilihan_beasiswa', '$berkas', '$status')";
        if (mysqli_query($connection, $query)) {
            echo "Data berhasil disimpan";
        } else {
            echo "Error: " . $query . "<br>" . mysqli_error($connection);
        }
    }
}
?>