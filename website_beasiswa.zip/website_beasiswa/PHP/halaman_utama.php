<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beasiswa Kampusku aja</title>
    <link rel="stylesheet" href="../bootstrap_extract/css/bootstrap.min.css">
    <link rel="stylesheet" href="../CSS/halaman_utama.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg" style="background-color: #beb925">
        <div class="container-fluid">
            <h3 class="navbar-brand">Kampusku Aja</h3>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                    <a class="nav-link" aria-current="page" href="halaman_utama.php">Home</a>
                    <a class="nav-link" href="daftar_beasiswa.php">Daftar Beasiswa</a>
                    <a class="nav-link" href="hasil_pendaftaran_beasiswa.php">Lihat Hasil Pendaftaran</a>
                </div>
            </div>
        </div>
    </nav>
<!--navigasi bar-->
    <div class="picture container-fluid mt-2">
        <img src="../picture/student.jpg" alt="student" class="img-fluid">
    </div>
<!--gambar-->
    <div class="footer container-fluid p-2 m-2" style="background-color: #beb925">
        <p class="text-center lead">Copyright &copy; 2024 Kampusku Aja</p>
    </div>
<!--footer-->
   
    <script src="../bootstrap_extract/js/bootstrap.bundle.min.js"></script>
</body>
</html>