<?php
//proses insert data dari form daftar beasiswa
include("koneksi_database.php");

try {
    if (isset($_POST['daftar'])) {
        insert_data($connection);
        header("Location: hasil_pendaftaran_beasiswa.php?success");
        exit;
    }
} catch (Exception $e) {
    echo $e->getMessage();
}
?>