<?php
//koneksi database
include('koneksi_database.php');
$query = mysqli_query($connection, "SELECT * FROM data_pendaftar");
$result = mysqli_fetch_all($query, MYSQLI_ASSOC);
// var_dump($result); die();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hasil Pendaftaran Beasiswa</title>
    <link rel="stylesheet" href="../bootstrap_extract/css/bootstrap.min.css">
    <link rel="stylesheet" href="../CSS/hasil_pendaftaran_beasiswa.css">
</head>
<body style="background-color: #f9fff3">
    <nav class="navbar navbar-expand-lg" style="background-color: #beb925">
        <div class="container-fluid">
            <h3 class="navbar-brand">Kampusku Aja</h3>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                    <a class="nav-link" aria-current="page" href="halaman_utama.php">Home</a>
                    <a class="nav-link" href="daftar_beasiswa.php">Daftar Beasiswa</a>
                    <a class="nav-link" href="hasil_pendaftaran_beasiswa.php">Lihat Hasil Pendaftaran</a>
                </div>
            </div>
        </div>
    </nav>
<!--navigasi bar-->

    <div class="table-responsive">
        <h1 class="text-center">Hasil Pendaftaran Beasiswa</h1>
        <table class="table table-striped mt-3">
            <thead>
                <tr class="text-center">
                    <th scope="col">No</th>
                    <th scope="col">Nama</th>
                    <th scope="col">Email</th>
                    <th scope="col">Nomor HP</th>
                    <th scope="col">Semester</th>
                    <th scope="col">IPK</th>
                    <th scope="col">Beasiswa</th>
                    <th scope="col">Berkas</th>
                    <th scope="col">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1; ?>
                <?php foreach ($result as $data) : ?>
                <tr class="text-center">
                    <th scope="row"><?= $i ?></th>
                    <td><?= $data['nama'] ?></td>
                    <td><?= $data['email'] ?></td>
                    <td><?= $data['nomor_hp'] ?></td>
                    <td><?= $data['semester'] ?></td>
                    <td><?= $data['ipk'] ?></td>
                    <td><?= $data['pilihan_beasiswa'] ?></td>
                    <?php if (!empty($data['berkas'])): ?>
                    <td><a class="btn btn-primary" href="../berkas/<?= $data['berkas'] ?>" download="<?= htmlspecialchars($data['berkas']) ?>">Download file</a></td>
                    <?php else: ?>
                    <td>-</td>
                    <?php endif; ?>
                    <td class="table-danger"><?= $data['status'] ?></td>
                </tr>
                <?php $i++; ?>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<!-- tabel hasil pendaftaran beasiswa -->
    <script src="../bootstrap_extract/js/bootstrap.bundle.min.js"></script>
</body>
</html>