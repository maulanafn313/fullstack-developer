<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Pendaftaran Beasiswa</title>
    <link rel="stylesheet" href="../bootstrap_extract/css/bootstrap.min.css">
    <link rel="stylesheet" href="../CSS/daftar_beasiswa.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg" style="background-color: #beb925">
        <div class="container-fluid">
            <h3 class="navbar-brand">Kampusku Aja</h3>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                    <a class="nav-link" aria-current="page" href="halaman_utama.php">Home</a>
                    <a class="nav-link" href="daftar_beasiswa.php">Daftar Beasiswa</a>
                    <a class="nav-link" href="hasil_pendaftaran_beasiswa.php">Lihat Hasil Pendaftaran</a>
                </div>
            </div>
        </div>
    </nav>
<!--navigasi bar-->

    <div class="container-fluid">
        <h1 class="text-center">Daftar Beasiswa</h1>
        <div class="form_daftar_beasiswa container-fluid border border-secondary p-3 rounded-2" style="background-color: #f9fff3">
            <form action="proses_pendaftaran_beasiswa.php" method="post" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="nama" class="form-label">Nama</label>
                    <input type="text" class="form-control" id="nama" name="nama" required>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>
                <div class="mb-3">
                    <label for="nomor_hp" class="form-label">Nomor HP</label>
                    <input type="text" class="form-control" id="nomor_hp" name="nomor_hp" required>
                </div>
                <div class="mb-3">
                    <label for="semester" class="form-label">Semester</label>
                    <select class="form-select" id="semester" name="semester" required>
                        <option>Pilih Semester</option>
                        <?php for ($i = 1; $i <= 8; $i++) : ?>
                            <option value="<?= $i ?>"><?= $i ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="ipk" class="form-label">IPK</label>
                    <input type="number" class="form-control" id="ipk" name="ipk" readonly value="3">
                </div>
                <?php if (3 >= 3) : ?>
                    <div class="mb-3">
                        <label for="pilihan_beasiswa" class="form-label">Pilih Beasiswa</label>
                        <select class="form-select" id="pilihan_beasiswa" name="pilihan_beasiswa" required>
                            <option value="">Pilih Beasiswa</option>
                            <option value="Akademik">Akademik</option>
                            <option value="Non-Akademik">Non-Akademik</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="berkas" class="form-label">Upload Berkas</label>
                        <input type="file" class="form-control" id="berkas" name="berkas" accept=".pdf," required>
                    </div>

                    <input type="hidden" name="status" readonly value="Belum diverifikasi">
                    
                    <button type="submit" name="daftar" class="btn btn-primary">Daftar</button>
                    <button type="reset" class="btn btn-danger">Batal</button>
                <?php else : ?>
                    <p>Maaf, IPK Anda kurang dari 3. Anda tidak dapat melanjutkan pendaftaran.</p>
                <?php endif; ?>
            </form>
        </div>
    </div>
<!--form registrasi pendaftaran beasiswa-->

    <div class="footer container-fluid p-2 mt-3" style="background-color: #beb925">
        <p class="text-center lead">Copyright &copy; 2024 Kampusku Aja</p>
    </div>
<!--footer-->
    <script src="../bootstrap_extract/js/bootstrap.bundle.min.js"></script>
</body>
</html>