const todoInput = document.getElementById('todo-input');
const todoList = document.getElementById('todo-list');

function addTodo() {
    const todoText = todoInput.value;
    if(todoText === '') return;

    const listItem = document.createElement('li');
    listItem.className = 'todo-item';
    listItem.innerHTML = `
        <input type="text" value="${todoText}" readonly>
        <button onclick = "editTodo(this)">Edit</button>
        <button onclick = "deleteTodo(this)">Delete</button>
    `;

    todoList.appendChild(listItem);
    todoInput.value = '';
}

// Fungsi untuk mengedit item to-do
function editTodo(button) {
    const listItem = button.parentElement;
    const input = listItem.querySelector('input[type="text"]');
    if (input.hasAttribute('readonly')) {
        input.removeAttribute('readonly');
        input.focus(); // Fokus pada input untuk memungkinkan pengguna langsung mulai mengedit
        button.textContent = 'Save';
    } else {
        input.setAttribute('readonly', 'readonly');
        button.textContent = 'Edit';
    }
}


function deleteTodo(button) {
    const listItem = button.parentElement;
    todoList.removeChild(listItem);
} 